package com.mentalfrostbyte.jello.font;

import java.awt.Font;

import org.newdawn.slick.UnicodeFont;

import net.minecraft.client.Minecraft;

public class SkidFont
extends JelloFontRenderer {
    private Minecraft mc;
    private MinecraftFontRenderer bla;
    private final UnicodeFont unicodeFont;
    private final int[] colorCodes;

    public SkidFont(Font font) {
        throw new Error("Unresolved compilation problems: \n\tThe import org.newdawn cannot be resolved\n\tThe import org.newdawn cannot be resolved\n\tUnicodeFont cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n\tColorEffect cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n\torg.newdawn cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n");
    }

    @Override
    public int drawString(String string, double f2, float f3, int n) {
        throw new Error("Unresolved compilation problems: \n\tUnicodeFont cannot be resolved to a type\n\torg.newdawn cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n");
    }

    @Override
    public int drawStringWithShadow(String string, double f2, float f3, int n) {
        throw new Error("Unresolved compilation problem: \n");
    }

    @Override
    public double getStringWidth(String string) {
        throw new Error("Unresolved compilation problem: \n\tUnicodeFont cannot be resolved to a type\n");
    }

    @Override
    public int getHeight() {
        throw new Error("Unresolved compilation problem: \n\tUnicodeFont cannot be resolved to a type\n");
    }

    public UnicodeFont getFont() {
        throw new Error("Unresolved compilation problems: \n\tUnicodeFont cannot be resolved to a type\n\tUnicodeFont cannot be resolved to a type\n");
    }
}

