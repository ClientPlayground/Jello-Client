 package com.mentalfrostbyte.jello.util;
 
 public class Value
 {
   public String name;
   
   public Value(String name) {
     this.name = name;
   }
   
   public String getName() {
     return this.name;
   }
 }

